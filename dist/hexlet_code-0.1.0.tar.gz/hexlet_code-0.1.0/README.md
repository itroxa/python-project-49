### Hexlet tests and linter status:
[![Actions Status](https://github.com/itroxa/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/itroxa/python-project-49/actions)
[![CodeClimate Maintainability](https://api.codeclimate.com/v1/badges/6cc531d28c4f258d66dd/maintainability)](https://codeclimate.com/github/itroxa/python-project-49/maintainability)
[![asciicast](https://asciinema.org/a/dmKIbAZa6dxd7Yy7hMQkN3fuY.svg)](https://asciinema.org/a/dmKIbAZa6dxd7Yy7hMQkN3fuY)
