### Hexlet tests and linter status:
[![Actions Status](https://github.com/itroxa/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/itroxa/python-project-49/actions)
### CodeClimate Maintainability
[![CodeClimate Maintainability](https://api.codeclimate.com/v1/badges/6cc531d28c4f258d66dd/maintainability)](https://codeclimate.com/github/itroxa/python-project-49/maintainability)
### Games modules demonstration
#### Brain-even gameplay
[![asciicast](https://asciinema.org/a/dmKIbAZa6dxd7Yy7hMQkN3fuY.svg)](https://asciinema.org/a/dmKIbAZa6dxd7Yy7hMQkN3fuY)
#### Brain-calc gameplay
[![asciicast](https://asciinema.org/a/iqZIMVeGwWiqLIWsC5PVQFUmr.svg)](https://asciinema.org/a/iqZIMVeGwWiqLIWsC5PVQFUmr)
### Brain-gcd gameplay
[![asciicast](https://asciinema.org/a/vNwVZBDPrimH0HyN8HcnvBfQu.svg)](https://asciinema.org/a/vNwVZBDPrimH0HyN8HcnvBfQu)
### Brain-progression gameplay
[![asciicast](https://asciinema.org/a/kjPx5WD4vsQ2miQOjIigYxWgk.svg)](https://asciinema.org/a/kjPx5WD4vsQ2miQOjIigYxWgk)