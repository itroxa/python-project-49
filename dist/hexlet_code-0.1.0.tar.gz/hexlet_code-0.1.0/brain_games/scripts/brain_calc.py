#!/usr/bin/env python3
import random
import prompt
dir(random)


def question():
    operators = ('+', '-', '*')
    first_value = random.randint(1, 50)
    second_value = random.randint(1, 50)
    operation_sign = random.choice(operators)
    if operation_sign == '+':
        correct_answer = sum(first_value, second_value)
    elif operation_sign == '-':
        correct_answer = sub(first_value, second_value)
    else:
        correct_answer = multiply(first_value, second_value)
    return (first_value, second_value, operation_sign, correct_answer)


def check_answer(user_answer, correct_answer):
    if user_answer == correct_answer:
        return True
    else:
        return False


def game(rounds=3):
    print("Welcome to the Brain Games!")
    user_name = prompt.string("May I have your name? ")
    print(f"Hello, {user_name}!")
    print("What is the result of the expression?")
    round_counter = 0
    while round_counter < rounds:
        first_value, second_value, operation_sign, correct_answer = question()
        print(f"Question: {first_value} {operation_sign} {second_value}")
        user_answer = prompt.integer("Your answer: ")
        check_result = check_answer(user_answer, correct_answer)
        if check_result:
            print("Correct!")
            round_counter += 1
        else:
            print(f"'{user_answer}' is wrong answer ;(. "
                  f"Correct answer is '{correct_answer}'.")
            print(f"Let's try again, {user_name}!")
            return
        if round_counter == rounds:
            print(f"Congratulations, {user_name}!")



def sum(a, b):
    return a + b


def sub(a, b):
    return a - b


def multiply(a, b):
    return a * b


def main():
    game()


if __name__ == '__main__':
    main()
