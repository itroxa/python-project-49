# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/itroxa/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/itroxa/python-project-49/actions)\n### CodeClimate Maintainability\n[![CodeClimate Maintainability](https://api.codeclimate.com/v1/badges/6cc531d28c4f258d66dd/maintainability)](https://codeclimate.com/github/itroxa/python-project-49/maintainability)\n### Games modules demonstration\n#### Brain-even gameplay\n[![asciicast](https://asciinema.org/a/dmKIbAZa6dxd7Yy7hMQkN3fuY.svg)](https://asciinema.org/a/dmKIbAZa6dxd7Yy7hMQkN3fuY)\n#### Brain-calc gameplay\n[![asciicast](https://asciinema.org/a/iqZIMVeGwWiqLIWsC5PVQFUmr.svg)](https://asciinema.org/a/iqZIMVeGwWiqLIWsC5PVQFUmr)\n### Brain-gcd gameplay\n[![asciicast](https://asciinema.org/a/vNwVZBDPrimH0HyN8HcnvBfQu.svg)](https://asciinema.org/a/vNwVZBDPrimH0HyN8HcnvBfQu)\n### Brain-progression gameplay\n[![asciicast](https://asciinema.org/a/kjPx5WD4vsQ2miQOjIigYxWgk.svg)](https://asciinema.org/a/kjPx5WD4vsQ2miQOjIigYxWgk)',
    'author': 'Vyacheslav Terskikh',
    'author_email': 'troxa843@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
